package ai.creatoros.smartclip

import androidx.media3.common.util.UnstableApi

import android.os.Bundle
import android.app.Activity
import android.app.TimePickerDialog
import java.util.Calendar
import android.content.Context
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF020821)
private val DeepBlue = Color(0xFF04143C)
private val Cyan = Color(0xFF00E9FF)
private val ElectricBlue = Color(0xFF087BFF)
private val WhiteBlue = Color(0xFFEAFBFF)

private val AppScreenGradient = Brush.verticalGradient(
    listOf(Color(0xFF020821), Color(0xFF071A3D), Color(0xFF030817))
)

class MainActivity : ComponentActivity() {
    @UnstableApi
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(2, 8, 33)
        window.navigationBarColor = android.graphics.Color.rgb(2, 8, 33)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
        setContent {
            MaterialTheme {
                SmartClipApp()
            }
        }
    }
}

@UnstableApi
@Composable
private fun SmartClipApp() {
    var currentScreen by remember { mutableStateOf("home") }
    var selectedSocialPlatform by remember { mutableStateOf("YOUTUBE") }
    var analysisVideo by remember { mutableStateOf<android.net.Uri?>(null) }
    var analysisClipCount by remember { mutableStateOf(0) }
    var analysisClipDuration by remember { mutableStateOf(0) }
    var analysisCaptionsEnabled by remember { mutableStateOf(true) }
    val appContext = androidx.compose.ui.platform.LocalContext.current
    val hostActivity = appContext as? ComponentActivity
    val youtubeAuthPrefs = remember(appContext) {
        appContext.getSharedPreferences("smart_clip_social_auth", Context.MODE_PRIVATE)
    }
    var youtubeConnected by remember {
        mutableStateOf(youtubeAuthPrefs.getBoolean("youtube_connected", false))
    }
    var youtubeLoginError by remember { mutableStateOf<String?>(null) }

    fun reportYoutubeLoginError(message: String) {
        youtubeLoginError = message
        android.widget.Toast.makeText(appContext, message, android.widget.Toast.LENGTH_LONG).show()
    }

    fun applyYoutubeAuthorization(authorizationResult: com.google.android.gms.auth.api.identity.AuthorizationResult) {
        val requiredScope = "https://www.googleapis.com/auth/youtube.readonly"
        val scopeGranted = authorizationResult.grantedScopes.orEmpty().contains(requiredScope)
        if (!authorizationResult.accessToken.isNullOrBlank() && scopeGranted) {
            youtubeConnected = true
            youtubeAuthPrefs.edit().putBoolean("youtube_connected", true).apply()
            youtubeLoginError = null
        } else {
            youtubeConnected = false
            youtubeAuthPrefs.edit().putBoolean("youtube_connected", false).apply()
            reportYoutubeLoginError(
                "O Google não confirmou a permissão de leitura do YouTube. Verifique as permissões da conta e tente novamente."
            )
        }
    }

    val youtubeAuthorizationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            runCatching {
                val activity = hostActivity ?: error("Não foi possível acessar a tela do aplicativo.")
                val data = result.data ?: error("O Google não retornou os dados da autorização.")
                Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(data)
            }.onSuccess { authorizationResult ->
                if (authorizationResult.hasResolution()) {
                    reportYoutubeLoginError("A autorização do YouTube ainda precisa ser concluída. Tente novamente.")
                } else {
                    applyYoutubeAuthorization(authorizationResult)
                }
            }.onFailure { error ->
                youtubeConnected = false
                youtubeAuthPrefs.edit().putBoolean("youtube_connected", false).apply()
                reportYoutubeLoginError(
                    error.localizedMessage ?: "Não foi possível concluir o login do YouTube."
                )
            }
        } else {
            reportYoutubeLoginError("A autorização do YouTube foi cancelada. Nenhuma conta foi conectada.")
        }
    }

    BackHandler(enabled = currentScreen != "home") {
        currentScreen = when (currentScreen) {
            "social_settings" -> "social"
            "analysis" -> "add_video"
            else -> "home"
        }
    }

    when (currentScreen) {
        "home" -> HomeScreen(
            onSettingsClick = { currentScreen = "settings" },
            onAddVideoClick = { currentScreen = "add_video" },
            onSocialClick = { currentScreen = "social" },
            onScheduledClick = { currentScreen = "scheduled" },
            onPerformanceClick = { currentScreen = "performance" }
        )
        "settings" -> AddApiScreen(
            onBack = { currentScreen = "home" },
            onCancel = { currentScreen = "home" },
            onSave = { currentScreen = "home" }
        )
        "add_video" -> AdjustCutsScreen(
            onBack = { currentScreen = "home" },
            onAnalyze = { video, count, duration, captions ->
                analysisVideo = video
                analysisClipCount = count
                analysisClipDuration = duration
                analysisCaptionsEnabled = captions
                currentScreen = "analysis"
            }
        )
        "analysis" -> VideoAnalysisScreen(
            videoUri = analysisVideo,
            requestedCount = analysisClipCount,
            requestedDurationSeconds = analysisClipDuration,
            captionsEnabled = analysisCaptionsEnabled,
            onBack = { currentScreen = "add_video" },
            onSchedule = { currentScreen = "scheduled" }
        )
        "social" -> SocialNetworksScreen(
            onBack = { currentScreen = "home" },
            onSettingsClick = { selectedSocialPlatform = it; currentScreen = "social_settings" },
            youtubeConnected = youtubeConnected,
            onYoutubeLogin = {
                youtubeLoginError = null
                val activity = hostActivity
                if (activity == null) {
                    reportYoutubeLoginError("Não foi possível iniciar o login nesta tela.")
                } else {
                    val request = AuthorizationRequest.builder()
                        .setRequestedScopes(
                            listOf(Scope("https://www.googleapis.com/auth/youtube.readonly"))
                        )
                        .build()
                    Identity.getAuthorizationClient(activity)
                        .authorize(request)
                        .addOnSuccessListener { authorizationResult ->
                            if (authorizationResult.hasResolution()) {
                                val pendingIntent = authorizationResult.pendingIntent
                                if (pendingIntent != null) {
                                    runCatching {
                                        youtubeAuthorizationLauncher.launch(
                                            IntentSenderRequest.Builder(pendingIntent.intentSender).build()
                                        )
                                    }.onFailure { error ->
                                        reportYoutubeLoginError(
                                            error.localizedMessage ?: "Não foi possível abrir a confirmação do Google."
                                        )
                                    }
                                } else {
                                    reportYoutubeLoginError("O Google não disponibilizou a confirmação do login.")
                                }
                            } else {
                                applyYoutubeAuthorization(authorizationResult)
                            }
                        }
                        .addOnFailureListener { error ->
                            reportYoutubeLoginError(
                                error.localizedMessage ?: "Falha ao conectar com o Google."
                            )
                        }
                }
            }
        )
        "social_settings" -> SocialScheduleScreen(platform = selectedSocialPlatform, onBack = { currentScreen = "social" })
        "scheduled" -> ScheduledVideosScreen(onBack = { currentScreen = "home" })
        "performance" -> PerformanceScreen(onBack = { currentScreen = "home" })
    }

    youtubeLoginError?.let { message ->
        AlertDialog(
            onDismissRequest = { youtubeLoginError = null },
            title = { Text("Login do YouTube") },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { youtubeLoginError = null }) { Text("OK") }
            }
        )
    }
}

private data class ApiPlatform(val id: String, val title: String, val subtitle: String, val iconType: String, val hint: String)

private val apiPlatforms = listOf(
    ApiPlatform("gemini", "ADICIONAR GEMINI", "Chave da API do Google", "gemini", "Cole sua chave da API Gemini"),
    ApiPlatform("youtube", "ADICIONAR YOUTUBE", "Conectar seu canal", "youtube", "Cole o token ou a chave de acesso do YouTube"),
    ApiPlatform("youtube_client_id", "ADICIONAR ID CLIENTE YOUTUBE", "ID do cliente OAuth 2.0 do Google", "youtube", "Cole o Client ID terminado em apps.googleusercontent.com"),
    ApiPlatform("instagram", "ADICIONAR INSTAGRAM", "Conectar sua conta", "instagram", "Cole o token de acesso do Instagram"),
    ApiPlatform("tiktok", "ADICIONAR TIK TOK", "Conectar sua conta", "tiktok", "Cole o token de acesso do TikTok")
)

private object ApiCredentialStore {
    private const val KEY_ALIAS = "smart_clip_api_credentials_key"
    private const val PREFS = "smart_clip_secure_api_credentials"

    private fun secretKey(): javax.crypto.SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? javax.crypto.SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String? = runCatching {
        val combined = Base64.decode(value, Base64.NO_WRAP)
        val iv = combined.copyOfRange(0, 12)
        val encrypted = combined.copyOfRange(12, combined.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }.getOrNull()

    private val credentialIds = apiPlatforms.map { it.id } + listOf("gemini_1", "gemini_2", "gemini_3")

    fun loadAll(context: Context): Map<String, String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val loaded = credentialIds.mapNotNull { id ->
            val encrypted = prefs.getString(id, null) ?: return@mapNotNull null
            val value = decrypt(encrypted) ?: return@mapNotNull null
            id to value
        }.toMap().toMutableMap()
        // Migra a chave antiga para o espaço 1 de forma persistente e atômica.
        // O valor criptografado é copiado sem expor a chave em texto simples.
        val legacyEncrypted = prefs.getString("gemini", null)
        if (loaded["gemini_1"].isNullOrBlank() && !legacyEncrypted.isNullOrBlank()) {
            val legacyValue = decrypt(legacyEncrypted)
            if (!legacyValue.isNullOrBlank()) {
                val migrated = prefs.edit()
                    .putString("gemini_1", legacyEncrypted)
                    .remove("gemini")
                    .commit()
                if (migrated) {
                    loaded["gemini_1"] = legacyValue
                    loaded.remove("gemini")
                } else {
                    // Mantém a chave disponível na sessão; o próximo salvamento
                    // tentará persistir o espaço 1 sem apagar a origem antes da hora.
                    loaded["gemini_1"] = legacyValue
                }
            }
        }
        return loaded
    }

    fun activeGeminiSlot(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = prefs.getInt("active_gemini_slot", -1)
        if (saved in 0..3) return saved
        return if (!loadAll(context)["gemini_1"].isNullOrBlank()) 1 else 0
    }

    fun saveActiveGeminiSlot(context: Context, slot: Int) {
        require(slot in 0..3)
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("active_gemini_slot", slot).commit()) {
            "Não foi possível salvar a chave Gemini ativa."
        }
    }

    fun loadActiveGeminiKey(context: Context): String {
        val slot = activeGeminiSlot(context)
        if (slot !in 1..3) return ""
        return loadAll(context)["gemini_$slot"].orEmpty()
    }

    fun saveAll(context: Context, values: Map<String, String>) {
        val editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        // Persiste também as remoções: uma credencial apagada da tela não pode
        // reaparecer ao abrir Configurações novamente.
        credentialIds.forEach { id ->
            val value = values[id]?.trim()
            if (value.isNullOrBlank()) editor.remove(id)
            else editor.putString(id, encrypt(value))
        }
        check(editor.commit()) { "Não foi possível salvar as credenciais neste aparelho." }
    }
}

@Composable
private fun AddApiScreen(onBack: () -> Unit, onCancel: () -> Unit, onSave: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var credentials by remember { mutableStateOf(ApiCredentialStore.loadAll(context)) }
    var activeGeminiSlot by remember { mutableStateOf(ApiCredentialStore.activeGeminiSlot(context)) }
    var selectedPlatform by remember { mutableStateOf<ApiPlatform?>(null) }
    var editingValue by remember { mutableStateOf("") }
    var saveError by remember { mutableStateOf<String?>(null) }
    var showSaveError by remember { mutableStateOf(false) }
    var connectionTestMessage by remember { mutableStateOf<String?>(null) }
    var testingConnection by remember { mutableStateOf(false) }
    val connectionTestScope = androidx.compose.runtime.rememberCoroutineScope()

    Box(
        modifier = Modifier.fillMaxSize().background(
            AppScreenGradient
        )
    ) {
        Box(
            Modifier.align(Alignment.TopEnd).size(190.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0x332E73FF), Color(0x002E73FF))))
        )
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(Color(0x332F68D8))
                        .border(1.5.dp, Color(0xFF6389E8), CircleShape).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White, modifier = Modifier.size(29.dp))
                }
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.clip(RoundedCornerShape(15.dp)).border(1.5.dp, Color(0xFF5478C8), RoundedCornerShape(15.dp))
                        .background(Color(0x221A3D88)).clickable(onClick = onCancel).padding(horizontal = 13.dp, vertical = 12.dp)
                ) { Text("CANCELAR", color = Color(0xFFD8E5FF), fontSize = 13.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp) }
                Spacer(Modifier.width(9.dp))
                Box(
                    Modifier.clip(RoundedCornerShape(15.dp)).background(Color(0xFF3478F6))
                        .clickable {
                            try {
                                ApiCredentialStore.saveAll(context, credentials)
                                ApiCredentialStore.saveActiveGeminiSlot(context, activeGeminiSlot)
                                onSave()
                            } catch (error: Exception) {
                                saveError = error.message ?: "Não foi possível salvar."
                                showSaveError = true
                            }
                        }.padding(horizontal = 15.dp, vertical = 12.dp)
                ) { Text("SALVAR", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
            }

            Spacer(Modifier.height(38.dp))
            Box(
                Modifier.size(74.dp).clip(RoundedCornerShape(19.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF397DFF), Color(0xFF2860E8))))
                    .border(1.dp, Color(0xFF78A2FF), RoundedCornerShape(19.dp)),
                contentAlignment = Alignment.Center
            ) { Text("API", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp) }

            Spacer(Modifier.height(10.dp))
            Text("ADICIONAR API", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text("Escolha uma plataforma para conectar", color = Color(0xFF9BAED7), fontSize = 15.sp, textAlign = TextAlign.Center)

            Spacer(Modifier.height(31.dp))
            Text("CHAVES GEMINI", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))
            (1..3).forEach { slot ->
                val keyId = "gemini_$slot"
                GeminiKeyCard(
                    slot = slot,
                    isConfigured = !credentials[keyId].isNullOrBlank(),
                    isActive = activeGeminiSlot == slot,
                    onEdit = {
                        editingValue = credentials[keyId].orEmpty()
                        selectedPlatform = ApiPlatform(keyId, "ADICIONAR GEMINI $slot", "Chave da API do Google — espaço $slot", "gemini", "Cole sua chave da API Gemini")
                    },
                    onToggle = {
                        activeGeminiSlot = if (activeGeminiSlot == slot) 0 else slot
                    }
                )
                Spacer(Modifier.height(12.dp))
            }
            apiPlatforms.filter { it.id != "gemini" }.forEachIndexed { index, platform ->
                ApiPlatformCard(platform, !credentials[platform.id].isNullOrBlank()) {
                    editingValue = credentials[platform.id].orEmpty()
                    selectedPlatform = platform
                }
                if (index != apiPlatforms.count { it.id != "gemini" } - 1) Spacer(Modifier.height(18.dp))
            }
            Spacer(Modifier.height(22.dp))
            Text("Você pode adicionar mais de uma plataforma", color = Color(0xFF7F96C8), fontSize = 13.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
        }
    }

    selectedPlatform?.let { platform ->
        AlertDialog(
            onDismissRequest = { selectedPlatform = null },
            containerColor = Color(0xFF142D68),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFD8E5FF),
            title = { Text(platform.title.replace("ADICIONAR ", "CONECTAR ")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(platform.subtitle, color = Color(0xFFB6C8EC), fontSize = 13.sp)
                    OutlinedTextField(
                        value = editingValue,
                        onValueChange = { editingValue = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text(platform.hint, color = Color(0xFF8FA5D1)) },
                        label = { Text(if (platform.id == "youtube_client_id") "ID do cliente OAuth 2.0" else "Chave / token de acesso") },
                        singleLine = false,
                        minLines = 2,
                        visualTransformation = if (platform.id == "youtube_client_id") androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = if (platform.id == "youtube_client_id") KeyboardType.Uri else KeyboardType.Password)
                    )
                    Text("O valor ficará protegido no armazenamento deste aparelho.", color = Color(0xFF9DB1DC), fontSize = 11.sp)
                    if (platform.id.startsWith("gemini")) {
                        TextButton(
                            enabled = !testingConnection && editingValue.isNotBlank(),
                            onClick = {
                                testingConnection = true
                                connectionTestMessage = "Testando conexão com o Gemini..."
                                connectionTestScope.launch {
                                    val result = withContext(kotlinx.coroutines.Dispatchers.IO) {
                                        runCatching { VideoAnalysisEngine.testConnection(editingValue.trim()) }
                                    }
                                    connectionTestMessage = result.fold(
                                        onSuccess = { it },
                                        onFailure = { it.message ?: "Não foi possível testar a conexão." }
                                    )
                                    testingConnection = false
                                }
                            }
                        ) {
                            Text(if (testingConnection) "TESTANDO..." else "TESTAR CONEXÃO", color = Color(0xFF82B0FF))
                        }
                        connectionTestMessage?.let {
                            Text(it, color = if (it.startsWith("Conexão Gemini válida")) Color(0xFF7EE6B1) else Color(0xFFFFB4B4), fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    credentials = credentials.toMutableMap().apply {
                        if (editingValue.isBlank()) remove(platform.id) else put(platform.id, editingValue.trim())
                    }
                    selectedPlatform = null
                }) { Text("ADICIONAR", color = Color(0xFF82B0FF)) }
            },
            dismissButton = {
                TextButton(onClick = { selectedPlatform = null }) { Text("CANCELAR", color = Color(0xFFB6C8EC)) }
            }
        )
    }

    if (showSaveError) {
        AlertDialog(
            onDismissRequest = { showSaveError = false },
            title = { Text("Não foi possível salvar") },
            text = { Text(saveError.orEmpty()) },
            confirmButton = { TextButton(onClick = { showSaveError = false }) { Text("OK") } }
        )
    }
}

 
@Composable
private fun GeminiKeyCard(
    slot: Int,
    isConfigured: Boolean,
    isActive: Boolean,
    onEdit: () -> Unit,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF1D3F91), Color(0xFF173477), Color(0xFF1B3477))))
            .border(1.4.dp, if (isActive) Color(0xFF65E6A5) else Color(0xFF00CFEA), RoundedCornerShape(20.dp))
            .padding(horizontal = 13.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).clickable(onClick = onEdit)) {
            Text("GEMINI API $slot", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(
                when {
                    isActive -> "ATIVA"
                    isConfigured -> "CONFIGURADA · DESATIVADA"
                    else -> "NÃO CONFIGURADA"
                },
                color = if (isActive) Color(0xFF7EE6B1) else Color(0xFFB6C8EC),
                fontSize = 10.sp
            )
        }
        TextButton(
            enabled = isConfigured,
            onClick = onToggle
        ) {
            Text(
                if (isActive) "DESATIVAR" else "ATIVAR",
                color = if (isActive) Color(0xFFFFC1C1) else Color(0xFF82B0FF),
                fontWeight = FontWeight.Bold
            )
        }
        TextButton(onClick = onEdit) {
            Text(if (isConfigured) "EDITAR" else "ADICIONAR", color = Color(0xFF82B0FF))
        }
    }
}

@Composable
private fun ApiPlatformCard(platform: ApiPlatform, isConfigured: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(23.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF1D3F91), Color(0xFF173477), Color(0xFF1B3477))))
            .border(1.4.dp, Color(0xFF00CFEA), RoundedCornerShape(23.dp))
            .clickable(onClick = onClick).padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(62.dp).clip(RoundedCornerShape(16.dp)).background(Color.White), contentAlignment = Alignment.Center) {
            when (platform.iconType) {
                "gemini" -> Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color(0xFF9061D9), modifier = Modifier.size(43.dp))
                "youtube" -> Box(Modifier.size(47.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFFFF1717)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(38.dp))
                }
                "instagram" -> Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFFFFC44D), Color(0xFFEF3683), Color(0xFF783DE5)))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.PhotoCamera, contentDescription = null, tint = Color.White, modifier = Modifier.size(34.dp))
                }
                else -> Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color.White, modifier = Modifier.size(34.dp))
                }
            }
        }
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(platform.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp)
            Spacer(Modifier.height(3.dp))
            Text(if (isConfigured) "Dado adicionado • toque para editar" else platform.subtitle, color = Color(0xFF9DB1DC), fontSize = 12.sp)
        }
        Box(Modifier.size(38.dp).clip(CircleShape).background(Color(0xFF347BF4)), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Add, contentDescription = "Adicionar " + platform.title, tint = Color.White, modifier = Modifier.size(27.dp))
        }
    }
}

@Composable
private fun HomeScreen(
    onSettingsClick: () -> Unit,
    onAddVideoClick: () -> Unit,
    onSocialClick: () -> Unit,
    onScheduledClick: () -> Unit,
    onPerformanceClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                AppScreenGradient
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    repeat(3) {
                        Box(
                            Modifier
                                .width(29.dp)
                                .height(4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Cyan)
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    NeonPill(
                        modifier = Modifier.clickable(onClick = onSettingsClick),
                        borderColor = ElectricBlue
                    ) {
                        Icon(Icons.Filled.Settings, contentDescription = null, tint = Cyan, modifier = Modifier.size(19.dp))
                        Text("CONFIGURAÇÕES", color = WhiteBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                NeonPill(borderColor = Color(0xFFFFD400), fill = Color(0xFF19122A)) {
                    Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = Color(0xFFFFD400), modifier = Modifier.size(18.dp))
                    Text("Premium", color = Color(0xFFFFE34D), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(30.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(112.dp)
                        .shadow(20.dp, CircleShape, ambientColor = ElectricBlue, spotColor = Cyan)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF16E7FF), Color(0xFF087BFF), Color(0xFF1236D8), Color(0xFF06133D))
                            ),
                            CircleShape
                        )
                        .border(2.dp, Color(0xFF72F5FF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .size(88.dp)
                            .border(1.dp, Color.White.copy(alpha = 0.28f), CircleShape)
                            .background(
                                Brush.radialGradient(listOf(Color(0xFF42DFFF), Color(0xFF075BDB), Color(0xFF06133D))),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "ST",
                            color = Color.White,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-2).sp
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("SMART ", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.7).sp)
                        Text("CLIP", color = Cyan, fontSize = 29.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.7).sp)
                    }
                    Box(
                        Modifier
                            .width(190.dp)
                            .height(4.dp)
                            .background(Brush.horizontalGradient(listOf(Color.Transparent, Color(0xFF00EFFF), ElectricBlue, Color.Transparent)), CircleShape)
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "SMART TECK TECNOLOGY",
                        color = Color(0xFF9BDFFF),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(Modifier.weight(1f).height(2.dp).background(Cyan))
                Text(
                    "  Crie • Edite • Publique com IA  ",
                    color = WhiteBlue,
                    fontSize = 14.sp,
                    fontStyle = FontStyle.Italic
                )
                Box(Modifier.weight(1f).height(2.dp).background(Cyan))
            }

            Spacer(Modifier.height(38.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ActionTile(
                    modifier = Modifier.weight(1f),
                    title = "ADICIONAR\nVÍDEO",
                    icon = { Icon(Icons.Filled.Movie, contentDescription = null, tint = Color.White, modifier = Modifier.size(42.dp)) },
                    accent = true,
                    onClick = onAddVideoClick
                )
                ActionTile(
                    modifier = Modifier.weight(1f),
                    title = "REDES\nSOCIAIS",
                    icon = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                SocialMark("youtube")
                                SocialMark("instagram")
                            }
                            SocialMark("tiktok")
                        }
                    },
                    onClick = onSocialClick
                )
            }

            Spacer(Modifier.height(20.dp))
            WideActionTile(
                title = "VÍDEOS PROGRAMADOS",
                icon = { Icon(Icons.Filled.CalendarMonth, contentDescription = null, tint = Cyan, modifier = Modifier.size(48.dp)) },
                onClick = onScheduledClick
            )
            Spacer(Modifier.height(16.dp))
            WideActionTile(
                title = "PAINEL DE DESEMPENHO",
                icon = { Icon(Icons.Filled.BarChart, contentDescription = null, tint = Cyan, modifier = Modifier.size(48.dp)) },
                onClick = onPerformanceClick
            )

            Spacer(Modifier.height(36.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.width(28.dp).height(2.dp).background(Cyan))
                Text(
                    "  SUA CRIATIVIDADE, POTENCIALIZADA POR IA!  ",
                    color = Cyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontStyle = FontStyle.Italic,
                    textAlign = TextAlign.Center
                )
                Box(Modifier.width(28.dp).height(2.dp).background(Cyan))
            }
            Spacer(Modifier.height(22.dp))
        }
    }
}

@Composable
private fun AdjustCutsScreen(onBack: () -> Unit, onAnalyze: (android.net.Uri?, Int, Int, Boolean) -> Unit) {
    var selectedVideo by remember { mutableStateOf<android.net.Uri?>(null) }
    var clipCount by remember { mutableStateOf(1) }
    var clipDuration by remember { mutableStateOf(0) }
    var verticalFormat by remember { mutableStateOf(false) }
    var captionsEnabled by remember { mutableStateOf(true) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            selectedVideo = uri
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(AppScreenGradient)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0B2447))
                        .border(1.5.dp, Color(0xFF2677B8), CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White, modifier = Modifier.size(29.dp))
                }
                Spacer(Modifier.width(22.dp))
                Text(
                    "AJUSTAR CORTES",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp
                )
            }

            Spacer(Modifier.height(12.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF12264F))
                    .border(2.dp, Color(0xFF168DFF), RoundedCornerShape(28.dp))
                    .clickable { videoPicker.launch(arrayOf("video/*")) }
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                if (selectedVideo != null) {
                    Box(Modifier.fillMaxWidth().weight(1f)) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)),
                            factory = { context ->
                                android.widget.VideoView(context).apply {
                                    setVideoURI(selectedVideo)
                                    setOnPreparedListener { player ->
                                        player.isLooping = true
                                        start()
                                    }
                                }
                            },
                            update = { videoView ->
                                if (videoView.tag != selectedVideo.toString()) {
                                    videoView.tag = selectedVideo.toString()
                                    videoView.setVideoURI(selectedVideo)
                                    videoView.setOnPreparedListener { player ->
                                        player.isLooping = true
                                        videoView.start()
                                    }
                                }
                            }
                        )
                        Box(
                            Modifier.align(Alignment.TopEnd)
                                .padding(6.dp)
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xE61A2340))
                                .border(1.dp, Color.White.copy(alpha = 0.75f), CircleShape)
                                .clickable {
                                    selectedVideo = null
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = "Remover vídeo", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("VÍDEO IMPORTADO • TOQUE PARA TROCAR", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp)
                } else {
                    Box(
                        Modifier.size(86.dp).clip(CircleShape).background(Color(0xFF123F78)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier.size(68.dp).clip(CircleShape)
                                .background(Brush.verticalGradient(listOf(Color(0xFF5595FF), Color(0xFF3475F0), Color(0xFF2451D8)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("↑", color = Color.White, fontSize = 43.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("IMPORTAR VÍDEO", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("Toque para escolher o arquivo", color = Color(0xFFAFC2E8), fontSize = 14.sp, textAlign = TextAlign.Center)
                }
            }

            CutCounterCard(
                title = "QUANTIDADE",
                subtitle = "número de clipes",
                value = clipCount,
                symbol = "#",
                onDecrease = { if (clipCount > 1) clipCount-- },
                onIncrease = { if (clipCount < 30) clipCount++ }
            )

            CutCounterCard(
                title = "DURAÇÃO",
                subtitle = "segundos por clipe",
                value = clipDuration,
                symbol = "◴",
                onDecrease = { if (clipDuration > 0) clipDuration-- },
                onIncrease = { if (clipDuration < 3600) clipDuration++ }
            )

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF1B477F), Color(0xFF142F59), Color(0xFF102B52))))
                    .border(1.5.dp, Color(0xFF00CFEA), RoundedCornerShape(28.dp))
                    .padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(Color(0xFF203F7C)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("▭", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("FORMATO DOS VÍDEOS", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text("proporção dos clipes", color = Color(0xFFAFC2E8), fontSize = 14.sp)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FormatOption(
                        modifier = Modifier.weight(1f),
                        label = "▱  NORMAL",
                        selected = !verticalFormat
                    ) { verticalFormat = false }
                    FormatOption(
                        modifier = Modifier.weight(1f),
                        label = "▯  9:16",
                        selected = verticalFormat
                    ) { verticalFormat = true }
                }
                Spacer(Modifier.height(16.dp))
                Text("LEGENDAS AUTOMÁTICAS", color = Color(0xFFFFD54F), fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp)
                Spacer(Modifier.height(9.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FormatOption(
                        modifier = Modifier.weight(1f),
                        label = "ATIVADAS",
                        selected = captionsEnabled
                    ) { captionsEnabled = true }
                    FormatOption(
                        modifier = Modifier.weight(1f),
                        label = "DESATIVADAS",
                        selected = !captionsEnabled
                    ) { captionsEnabled = false }
                }
            }

            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(92.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF397CF4), Color(0xFF2451D8))))
                    .clickable { selectedVideo?.let { onAnalyze(it, clipCount, clipDuration, captionsEnabled) } },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
                    Text("ANALISAR", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }


}

@UnstableApi
@Composable
private fun VideoAnalysisScreen(
    videoUri: android.net.Uri?,
    requestedCount: Int,
    requestedDurationSeconds: Int,
    captionsEnabled: Boolean,
    onBack: () -> Unit,
    onSchedule: () -> Unit
) {
    data class ClipRow(val suggestion: SmartClipSuggestion, val file: java.io.File)
    val context = androidx.compose.ui.platform.LocalContext.current
    var status by remember(videoUri) { mutableStateOf("Preparando análise...") }
    var errorMessage by remember(videoUri) { mutableStateOf<String?>(null) }
    val processedClips = remember(videoUri) { mutableStateListOf<ClipRow>() }
    val navy = Color(0xFF071936)
    val line = Color(0xFF2677B8)
    val scheduleScope = androidx.compose.runtime.rememberCoroutineScope()
    var scheduling by remember { mutableStateOf(false) }

    LaunchedEffect(videoUri) {
        if (videoUri == null) {
            errorMessage = "Volte e importe um vídeo antes de analisar."
            return@LaunchedEffect
        }
        val apiKey = ApiCredentialStore.loadActiveGeminiKey(context)
        if (apiKey.isBlank()) {
            errorMessage = "Ative uma chave Gemini em Configurações."
            status = "Gemini não conectado"
            return@LaunchedEffect
        }
        try {
            val suggestions = withContext(kotlinx.coroutines.Dispatchers.IO) {
                VideoAnalysisEngine.analyze(
                    context = context,
                    videoUri = videoUri,
                    apiKey = apiKey,
                    requestedCount = if (requestedCount > 0) requestedCount else 5,
                    requestedDurationSeconds = requestedDurationSeconds,
                    onStatus = { message ->
                        android.os.Handler(android.os.Looper.getMainLooper()).post { status = message }
                    }
                )
            }
            var failedCuts = 0
            suggestions.forEachIndexed { index, suggestion ->
                status = "Gerando corte ${index + 1} de ${suggestions.size}..."
                try {
                    val rawOutput = withContext(kotlinx.coroutines.Dispatchers.IO) {
                        VideoCutEngine.cut(context, videoUri, suggestion, index)
                    }
                    val output = if (captionsEnabled && suggestion.captions.isNotEmpty()) {
                        status = "Inserindo legendas no corte ${index + 1}..."
                        try {
                            VideoCaptionBurner.burn(context, rawOutput, suggestion.captions, index).also {
                                rawOutput.delete()
                            }
                        } catch (captionError: Exception) {
                            rawOutput.delete()
                            throw captionError
                        }
                    } else {
                        rawOutput
                    }
                    processedClips.add(ClipRow(suggestion, output))
                } catch (cutError: Exception) {
                    failedCuts++
                    status = "Corte ${index + 1} não foi gerado; continuando..."
                }
            }
            status = when {
                processedClips.isEmpty() -> "Nenhum corte válido foi gerado"
                failedCuts > 0 -> "${processedClips.size} cortes gerados; ${failedCuts} falharam"
                else -> "Análise e cortes concluídos"
            }
            if (processedClips.isEmpty()) {
                errorMessage = "O Gemini encontrou momentos, mas não foi possível gerar os arquivos de vídeo. Tente outro vídeo."
            }
        } catch (error: Exception) {
            errorMessage = error.message ?: "Não foi possível analisar o vídeo."
            status = "Não foi possível concluir"
        }
    }

    Column(
        Modifier.fillMaxSize().background(navy).padding(horizontal = 7.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White,
                modifier = Modifier.size(28.dp).clickable(onClick = onBack))
            Spacer(Modifier.weight(1f))
            Text("GERANDO CORTES", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.size(28.dp))
        }
        Box(Modifier.padding(top = 7.dp).width(48.dp).height(3.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF438AFF)))
        Spacer(Modifier.height(12.dp))

        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF0D2349))
                .border(1.dp, line, RoundedCornerShape(12.dp)).padding(horizontal = 9.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.fillMaxWidth().height(105.dp).clip(RoundedCornerShape(9.dp))
                    .background(Color(0xFF102A57)).border(1.dp, Color(0xFF4267A5), RoundedCornerShape(9.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (videoUri != null) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            android.widget.VideoView(ctx).apply {
                                setVideoURI(videoUri)
                                setOnPreparedListener { player -> player.isLooping = true; start() }
                            }
                        }
                    )
                } else {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(46.dp))
                }
                Text(status, color = Color(0xFFD7E5FF), fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).background(Color(0xAA071835)).padding(4.dp))
            }
            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Cortes gerados: ${processedClips.size}", color = Color(0xFFAFC2E8), fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text(if (errorMessage == null && processedClips.isEmpty()) "..." else if (errorMessage != null) "Erro" else "OK",
                    color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(5.dp))
            Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF31466B))) {
                if (processedClips.isNotEmpty()) {
                    Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0xFF438AFF)))
                }
            }
        }

        errorMessage?.let { message ->
            Text(message, color = Color(0xFFFF9A9A), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(8.dp))
        }

        Spacer(Modifier.height(10.dp))
        if (processedClips.isEmpty() && errorMessage == null) {
            Text("O Gemini está analisando o conteúdo. Os cortes aparecerão aqui, um por um.",
                color = Color(0xFFB8C9E8), fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(14.dp))
        }
        Column(
            Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            processedClips.forEachIndexed { index, clip ->
                Row(
                    Modifier.fillMaxWidth().height(104.dp).clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF10264E)).border(1.dp, line, RoundedCornerShape(8.dp))
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AndroidView(
                        modifier = Modifier.width(112.dp).fillMaxHeight().clip(RoundedCornerShape(6.dp)),
                        factory = { ctx ->
                            android.widget.VideoView(ctx).apply {
                                setVideoURI(android.net.Uri.fromFile(clip.file))
                                setOnPreparedListener { player -> player.isLooping = true; start() }
                                setOnClickListener { if (isPlaying) pause() else start() }
                            }
                        }
                    )
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        Text("${clip.suggestion.platform} • CORTE ${index + 1}", color = Color(0xFF8DBBFF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(clip.suggestion.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 3)
                    }
                }
            }
        }

        Spacer(Modifier.height(9.dp))
        Box(
            Modifier.fillMaxWidth(0.46f).height(42.dp).clip(RoundedCornerShape(9.dp))
                .background(AppScreenGradient)
                .clickable(enabled = processedClips.isNotEmpty() && !scheduling, onClick = {
                    scheduling = true
                    scheduleScope.launch {
                        try {
                            val outcome = withContext(kotlinx.coroutines.Dispatchers.IO) {
                                ScheduledVideoStore.schedule(context, processedClips.map { it.suggestion to it.file })
                            }
                            if (outcome.scheduled > 0) onSchedule()
                            else errorMessage = if (outcome.missingPlatforms.isNotEmpty()) {
                                "Configure horários para: ${outcome.missingPlatforms.joinToString(", ")}."
                            } else "Não foi possível salvar os vídeos programados."
                        } catch (error: Exception) {
                            errorMessage = error.message ?: "Falha ao salvar os vídeos programados."
                        } finally {
                            scheduling = false
                        }
                    }
                }),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Icon(Icons.Filled.CalendarMonth, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                Text(if (scheduling) "PROGRAMANDO..." else "PROGRAMAR", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            }
        }
    }
}

@Composable
private fun CutCounterCard(
    title: String,
    subtitle: String,
    value: Int,
    symbol: String,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(112.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF1B477F), Color(0xFF142F59), Color(0xFF102B52))))
            .border(1.5.dp, Color(0xFF00CFEA), RoundedCornerShape(28.dp))
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(58.dp).clip(RoundedCornerShape(19.dp)).background(Color(0xFF203F7C)),
            contentAlignment = Alignment.Center
        ) {
            Text(symbol, color = Color.White, fontSize = 35.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(subtitle, color = Color(0xFFAFC2E8), fontSize = 13.sp)
        }
        CounterButton("−", enabled = value > 0, onClick = onDecrease, filled = false)
        Spacer(Modifier.width(7.dp))
        Box(
            Modifier
                .width(66.dp)
                .height(56.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF0A1B38), Color(0xFF07142B), Color(0xFF030817))))
                .border(1.5.dp, Color(0xFF2677B8), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(value.toString(), color = Color(0xFFAFC2E8), fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(7.dp))
        CounterButton("+", enabled = true, onClick = onIncrease, filled = true)
    }
}

@Composable
private fun CounterButton(label: String, enabled: Boolean, onClick: () -> Unit, filled: Boolean) {
    Box(
        Modifier
            .size(54.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (filled) Color(0xFF3475F0) else Color(0xFF0A1735))
            .border(if (filled) 0.dp else 1.5.dp, Color(0xFF2677B8), RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (enabled) Color.White else Color(0xFF52668F), fontSize = 31.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun FormatOption(modifier: Modifier, label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier
            .height(72.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (selected) Brush.verticalGradient(listOf(Color(0xFF397CF4), Color(0xFF2451D8))) else Brush.verticalGradient(listOf(Color(0xFF0A1735), Color(0xFF0A1735))))
            .border(1.5.dp, if (selected) Color(0xFF397CF4) else Color(0xFF2677B8), RoundedCornerShape(22.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
    }
}

@Composable
private fun PerformanceScreen(onBack: () -> Unit) {
    var refreshVersion by remember { mutableStateOf(0) }
    val platforms = listOf(
        Triple("YOUTUBE", Color(0xFFFF626A), "youtube"),
        Triple("INSTAGRAM", Color(0xFFF05BAA), "instagram"),
        Triple("TIKTOK", Color(0xFF18D5E8), "tiktok")
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(AppScreenGradient)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0B2447))
                        .border(1.5.dp, Color(0xFF2677B8), CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White, modifier = Modifier.size(29.dp))
                }
                Spacer(Modifier.weight(1f))
                Text(
                    "DESEMPENHO",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp
                )
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(48.dp))
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF087BFF))
                        .border(1.dp, Cyan, RoundedCornerShape(14.dp))
                        .clickable { refreshVersion++ }
                        .padding(horizontal = 20.dp, vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("ATUALIZAR", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(30.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF173D72), Color(0xFF102B52), Color(0xFF0D1B3A))))
                    .border(1.5.dp, Color(0xFF00CFEA), RoundedCornerShape(30.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                platforms.forEach { (name, accent, _) ->
                    PlatformPerformanceCard(name = name, accent = accent)
                }

                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(30.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF1B477F), Color(0xFF142F59), Color(0xFF102B52))))
                        .border(1.5.dp, Color(0xFF00CFEA), RoundedCornerShape(30.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0xFF203F7C)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("◎", color = Color.White, fontSize = 39.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(16.dp))
                        Text(
                            "VISUALIZAÇÕES DO DIA",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.4.sp
                        )
                    }

                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 26.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("0", color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.width(18.dp))
                        Text(
                            "TOTAL HOJE",
                            color = Color(0xFFAFC2E8),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    platforms.forEach { (name, accent, _) ->
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(Modifier.width(9.dp).height(40.dp).clip(RoundedCornerShape(8.dp)).background(accent))
                            Text(name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp, modifier = Modifier.width(126.dp))
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(13.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Brush.verticalGradient(listOf(Color(0xFF0A1B38), Color(0xFF07142B), Color(0xFF030817))))
                                    .border(1.dp, Color(0xFF2677B8), RoundedCornerShape(20.dp))
                            )
                            Text("0", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(30.dp), textAlign = TextAlign.End)
                        }
                    }
                }
            }

            Text(
                "Os indicadores serão atualizados quando as contas estiverem conectadas a fontes de dados.",
                color = Color(0xFF8FA6D2),
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun PlatformPerformanceCard(name: String, accent: Color) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(25.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF1B477F), Color(0xFF142F59), Color(0xFF102B52))))
            .border(1.5.dp, Color(0xFF2677B8), RoundedCornerShape(25.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(8.dp).height(23.dp).clip(RoundedCornerShape(8.dp)).background(accent))
            Spacer(Modifier.width(10.dp))
            Text(name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PerformanceMetric("♙", "INSCRITOS HOJE", "0", accent, Modifier.weight(1f))
            PerformanceMetric("♡", "CURTIDAS", "0", accent, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PerformanceMetric("▱", "COMENTÁRIOS", "0", accent, Modifier.weight(1f))
            PerformanceMetric("◎", "VISUALIZAÇÕES", "0", accent, Modifier.weight(1f))
        }
    }
}

@Composable
private fun PerformanceMetric(
    symbol: String,
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .height(78.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF0A1B38), Color(0xFF07142B), Color(0xFF030817))))
            .border(1.2.dp, Color(0xFF2677B8), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(symbol, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Color(0xFFAFC2E8), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Text(value, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun SocialNetworksScreen(
    onBack: () -> Unit,
    onSettingsClick: (String) -> Unit,
    youtubeConnected: Boolean,
    onYoutubeLogin: () -> Unit
) {
    val platforms = listOf(
        Triple("YOUTUBE", Color(0xFFE51F27), "youtube"),
        Triple("INSTAGRAM", Color(0xFFD92E70), "instagram"),
        Triple("TIKTOK", Color(0xFF0F94B5), "tiktok")
    )
    Box(Modifier.fillMaxSize().background(AppScreenGradient)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 24.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0xFF0B2447)).border(1.5.dp, Color(0xFF2677B8), CircleShape).clickable(onClick = onBack), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White, modifier = Modifier.size(29.dp))
                }
                Spacer(Modifier.weight(1f))
                Text("REDES SOCIAIS", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(48.dp))
            }
            Spacer(Modifier.height(28.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(Brush.verticalGradient(listOf(Color(0xFF173D72), Color(0xFF102B52), Color(0xFF0D1B3A)))).border(1.5.dp, Color(0xFF00CFEA), RoundedCornerShape(30.dp)).padding(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    platforms.forEach { (name, accent, type) ->
                        SocialPlatformCard(
                            name = name,
                            accent = accent,
                            type = type,
                            modifier = Modifier.weight(1f),
                            isYoutubeConnected = name == "YOUTUBE" && youtubeConnected,
                            onYoutubeLogin = if (name == "YOUTUBE") onYoutubeLogin else ({})
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    platforms.forEach { (name, _, _) ->
                        Box(Modifier.size(58.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color(0xFF17416F), Color(0xFF102B52)))).border(1.5.dp, Color(0xFF168DFF), CircleShape).clickable { onSettingsClick(name) }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Settings, contentDescription = "Configurações de $name", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.width(112.dp).height(5.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF2677B8)))
                Spacer(Modifier.height(26.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(58.dp).clip(CircleShape).background(Color(0xFF2451D8)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.ContentCut, contentDescription = null, tint = Color.White, modifier = Modifier.size(35.dp))
                    }
                    Spacer(Modifier.width(16.dp))
                    Text("SMART CLIP", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
                }
            }
        }
    }
}

@Composable
private fun SocialScheduleScreen(platform: String, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("smart_clip_social_schedules", Context.MODE_PRIVATE) }
    val times = remember(platform) {
        mutableStateListOf<String>().apply { addAll(prefs.getStringSet(platform, emptySet()).orEmpty().sorted()) }
    }
    val accent = when (platform) {
        "YOUTUBE" -> Color(0xFFE51F27)
        "INSTAGRAM" -> Color(0xFFD92E70)
        else -> Color(0xFF0FABC5)
    }
    fun saveTimes() { prefs.edit().putStringSet(platform, times.toSet()).apply() }
    Box(Modifier.fillMaxSize().background(AppScreenGradient)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color(0xFF17416F), Color(0xFF102B52)))).border(1.5.dp, Color(0xFF2677B8), CircleShape).clickable(onClick = onBack), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.weight(1f))
                Text(platform, color = Color.White, fontSize = 23.sp, letterSpacing = 2.sp)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(54.dp))
            }
            Spacer(Modifier.height(22.dp))
            Box(Modifier.size(88.dp).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
                when (platform) {
                    "YOUTUBE" -> Icon(Icons.Filled.SmartDisplay, null, tint = Color.White, modifier = Modifier.size(49.dp))
                    "INSTAGRAM" -> Box(Modifier.size(48.dp).border(3.5.dp, Color.White, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(22.dp).border(3.5.dp, Color.White, CircleShape))
                        Box(Modifier.align(Alignment.TopEnd).padding(7.dp).size(6.dp).clip(CircleShape).background(Color.White))
                    }
                    else -> Box(Modifier.size(54.dp), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.MusicNote, null, tint = Color(0xFF25F4EE), modifier = Modifier.offset(x = (-3).dp, y = 1.dp).size(51.dp))
                        Icon(Icons.Filled.MusicNote, null, tint = Color(0xFFFE2C55), modifier = Modifier.offset(x = 3.dp, y = (-1).dp).size(51.dp))
                        Icon(Icons.Filled.MusicNote, null, tint = Color.White, modifier = Modifier.size(49.dp))
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color(0xFF14264F)).border(1.5.dp, Color(0xFF00CFEA), RoundedCornerShape(28.dp)).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(6.dp).height(28.dp).clip(RoundedCornerShape(8.dp)).background(accent))
                    Spacer(Modifier.width(12.dp))
                    Text("HORÁRIOS", color = Color.White, fontSize = 19.sp, letterSpacing = 2.sp)
                }
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth().height(92.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF071633)).border(1.3.dp, Color(0xFF2677B8), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                    Text("Selecione o horário ao adicionar", color = Color(0xFF9FB5E5), fontSize = 13.sp)
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth().height(62.dp).clip(RoundedCornerShape(19.dp).let { it }).background(Brush.verticalGradient(listOf(Color(0xFF4D83FF), Color(0xFF2454E8), Color(0xFF1944C8)))).clickable {
                    val now = Calendar.getInstance()
                    TimePickerDialog(context, { _, hour, minute ->
                        val value = String.format("%02d:%02d", hour, minute)
                        if (!times.contains(value)) { times.add(value); times.sort(); saveTimes() }
                    }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
                }, horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("ADICIONAR HORÁRIO", color = Color.White, fontSize = 17.sp, letterSpacing = 2.sp)
                }
                Spacer(Modifier.height(14.dp))
                if (times.isEmpty()) {
                    Text("Nenhum horário adicionado.", color = Color(0xFFAFC2E8), fontSize = 13.sp, modifier = Modifier.padding(vertical = 12.dp))
                } else {
                    times.toList().forEach { time ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).height(58.dp).clip(RoundedCornerShape(17.dp)).background(Color.White).padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("◷", color = Color(0xFF101827), fontSize = 27.sp)
                            Spacer(Modifier.width(14.dp))
                            Text(time, color = Color(0xFF101827), fontSize = 21.sp, modifier = Modifier.weight(1f))
                            Text("×", color = Color(0xFF101827), fontSize = 30.sp, modifier = Modifier.clickable { times.remove(time); saveTimes() }.padding(horizontal = 5.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialPlatformCard(
    name: String,
    accent: Color,
    type: String,
    modifier: Modifier = Modifier,
    isYoutubeConnected: Boolean = false,
    onYoutubeLogin: () -> Unit = {}
) {
    Column(
        modifier
            .height(300.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(
                Brush.verticalGradient(
                    listOf(accent.copy(alpha = 0.22f), Color(0xFF142F59), Color(0xFF142F59))
                )
            )
            .border(1.2.dp, accent.copy(alpha = 0.85f), RoundedCornerShape(32.dp))
            .padding(vertical = 18.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(126.dp)
                .clip(CircleShape)
                .background(accent.copy(alpha = 0.22f)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(accent),
                contentAlignment = Alignment.Center
            ) {
                when (type) {
                    "youtube" -> Box(
                        Modifier
                            .width(48.dp)
                            .height(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(3.dp, Color.White, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(27.dp))
                    }
                    "instagram" -> Box(Modifier.size(54.dp).border(4.dp, Color.White, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(25.dp).border(4.dp, Color.White, CircleShape))
                        Box(Modifier.align(Alignment.TopEnd).padding(8.dp).size(7.dp).clip(CircleShape).background(Color.White))
                    }
                    else -> Box(Modifier.size(62.dp), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color(0xFF25F4EE), modifier = Modifier.offset(x = (-3).dp, y = 1.dp).size(58.dp))
                        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color(0xFFFE2C55), modifier = Modifier.offset(x = 3.dp, y = (-1).dp).size(58.dp))
                        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color.White, modifier = Modifier.size(56.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            name,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.1.sp,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
        if (type == "youtube") {
            if (isYoutubeConnected) {
                Spacer(Modifier.height(7.dp))
                Text(
                    "CONECTADA",
                    color = Color(0xFF35D07F),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.6.sp,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(7.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 2.dp)
                    .height(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF174F9A))
                    .border(1.dp, Color(0xFF70A9FF), RoundedCornerShape(10.dp))
                    .clickable(onClick = onYoutubeLogin),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "FAZER LOGIN",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.2.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }
    }
}


private data class ScheduledVideoEntry(
    val id: String, val platform: String, val title: String, val filePath: String,
    val scheduledAt: Long, val description: String, val hashtags: String
)
private data class ScheduleOutcome(val scheduled: Int, val missingPlatforms: List<String>)

private object ScheduledVideoStore {
    private const val PREFS = "smart_clip_scheduled_videos"
    private const val KEY = "entries"

    private fun read(context: Context): MutableList<ScheduledVideoEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        // Preferimos recuperar entradas válidas em vez de derrubar a tela inteira
        // quando os dados locais estiverem incompletos ou corrompidos.
        val array = runCatching { org.json.JSONArray(raw) }.getOrElse { return mutableListOf() }
        val validPlatforms = setOf("YOUTUBE", "INSTAGRAM", "TIKTOK")
        val entries = mutableListOf<ScheduledVideoEntry>()
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val entry = ScheduledVideoEntry(
                id = item.optString("id"),
                platform = item.optString("platform").uppercase(java.util.Locale.ROOT),
                title = item.optString("title"),
                filePath = item.optString("filePath"),
                scheduledAt = item.optLong("scheduledAt", 0L),
                description = item.optString("description"),
                hashtags = item.optString("hashtags")
            )
            val file = java.io.File(entry.filePath)
            if (entry.id.isBlank() || entry.platform !in validPlatforms ||
                entry.title.isBlank() || entry.scheduledAt <= 0L ||
                entry.filePath.isBlank() || !file.isFile || file.length() <= 0L) continue
            entries.add(entry)
        }
        return entries.distinctBy { it.id }.toMutableList()
    }

    private fun save(context: Context, entries: List<ScheduledVideoEntry>) {
        val array = org.json.JSONArray()
        entries.forEach { e -> array.put(org.json.JSONObject()
            .put("id", e.id).put("platform", e.platform).put("title", e.title)
            .put("filePath", e.filePath).put("scheduledAt", e.scheduledAt)
            .put("description", e.description).put("hashtags", e.hashtags)) }
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, array.toString()).commit()) { "Não foi possível salvar a programação." }
    }

    fun schedule(context: Context, clips: List<Pair<SmartClipSuggestion, java.io.File>>): ScheduleOutcome {
        val prefs = context.getSharedPreferences("smart_clip_social_schedules", Context.MODE_PRIVATE)
        val entries = read(context)
        val now = System.currentTimeMillis()
        val lastByPlatform = mutableMapOf<String, Long>()
        val directory = java.io.File(context.filesDir, "scheduled_videos").apply { mkdirs() }
        var scheduled = 0
        val missing = linkedSetOf<String>()
        val createdFiles = mutableListOf<java.io.File>()

        clips.forEach { (suggestion, source) ->
            val platform = suggestion.platform.trim().uppercase(java.util.Locale.ROOT)
            val times = prefs.getStringSet(platform, emptySet()).orEmpty().sorted()
            if (times.isEmpty()) { missing.add(platform); return@forEach }
            if (!source.exists() || source.length() == 0L) return@forEach

            val previous = maxOf(now, lastByPlatform[platform] ?: now)
            val nextAt = times.mapNotNull { value ->
                val parts = value.split(":")
                if (parts.size != 2) return@mapNotNull null
                val hour = parts[0].toIntOrNull() ?: return@mapNotNull null
                val minute = parts[1].toIntOrNull() ?: return@mapNotNull null
                if (hour !in 0..23 || minute !in 0..59) return@mapNotNull null
                java.util.Calendar.getInstance().apply {
                    timeInMillis = previous
                    set(java.util.Calendar.HOUR_OF_DAY, hour)
                    set(java.util.Calendar.MINUTE, minute)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                    if (timeInMillis <= previous) add(java.util.Calendar.DAY_OF_YEAR, 1)
                }.timeInMillis
            }.minOrNull()
            if (nextAt == null) { missing.add(platform); return@forEach }

            val id = java.util.UUID.randomUUID().toString()
            val destination = java.io.File(directory, "${platform.lowercase(java.util.Locale.ROOT)}_${id}.mp4")
            try {
                source.inputStream().use { input -> destination.outputStream().use { output -> input.copyTo(output, 64 * 1024) } }
                if (!destination.exists() || destination.length() != source.length()) {
                    destination.delete()
                    return@forEach
                }
                createdFiles.add(destination)
            } catch (copyError: Exception) {
                destination.delete()
                // Rollback das cópias anteriores: evita arquivos órfãos se um
                // dos vídeos não puder ser copiado para a pasta de programação.
                createdFiles.forEach { it.delete() }
                throw copyError
            }
            entries.add(ScheduledVideoEntry(id, platform, suggestion.title, destination.absolutePath, nextAt,
                suggestion.description, suggestion.hashtags))
            lastByPlatform[platform] = nextAt
            scheduled++
        }
        try {
            save(context, entries.sortedBy { it.scheduledAt })
        } catch (saveError: Exception) {
            // Não deixa arquivos órfãos se a gravação da lista falhar.
            createdFiles.forEach { it.delete() }
            throw saveError
        }
        return ScheduleOutcome(scheduled, missing.toList())
    }

    fun all(context: Context): List<ScheduledVideoEntry> = read(context).sortedBy { it.scheduledAt }
}

@Composable
private fun ScheduledVideosScreen(onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val entries = remember { mutableStateListOf<ScheduledVideoEntry>() }
    LaunchedEffect(Unit) { entries.clear(); entries.addAll(ScheduledVideoStore.all(context)) }
    Box(Modifier.fillMaxSize().background(AppScreenGradient).padding(20.dp)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF18366F))
                    .border(1.5.dp, Color(0xFF00CFEA), CircleShape).clickable(onClick = onBack), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.weight(1f))
                Text("VÍDEOS PROGRAMADOS", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.weight(1f)); Spacer(Modifier.size(46.dp))
            }
            Spacer(Modifier.height(20.dp))
            if (entries.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nenhum vídeo programado.", color = Color(0xFFAFC2E8), fontSize = 14.sp, textAlign = TextAlign.Center)
                }
            } else {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    entries.forEach { entry ->
                        val date = java.text.SimpleDateFormat("dd/MM/yyyy • HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date(entry.scheduledAt))
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF14264F))
                            .border(1.dp, Color(0xFF2677B8), RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(entry.platform, color = Color(0xFF8DBBFF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp))
                                Text(entry.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                                Spacer(Modifier.height(6.dp))
                                Text(date, color = Color(0xFFAFC2E8), fontSize = 12.sp)
                                Text("Salvo para programação", color = Color(0xFFFFD27A), fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyFeatureScreen(title: String, onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppScreenGradient)
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF18366F))
                    .border(1.5.dp, Color(0xFF00CFEA), CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.ArrowBack,
                    contentDescription = "Voltar",
                    tint = Color.White,
                    modifier = Modifier.size(27.dp)
                )
            }
            Spacer(Modifier.weight(1f))
            Text(
                "SMART CLIP",
                color = Cyan,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.size(46.dp))
        }
        Text(
            text = title,
            modifier = Modifier.align(Alignment.Center),
            color = Color.White,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun NeonPill(
    modifier: Modifier = Modifier,
    borderColor: Color,
    fill: Color = Color(0xFF071B48),
    content: @Composable () -> Unit
) {
    Row(
        modifier = modifier
            .shadow(10.dp, RoundedCornerShape(30.dp), ambientColor = borderColor, spotColor = borderColor)
            .clip(RoundedCornerShape(30.dp))
            .background(fill)
            .border(BorderStroke(1.5.dp, borderColor), RoundedCornerShape(30.dp))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) { content() }
}

@Composable
private fun ActionTile(
    modifier: Modifier = Modifier,
    title: String,
    icon: @Composable () -> Unit,
    accent: Boolean = false,
    onClick: () -> Unit = {}
) {
    Row(
        modifier = modifier
            .height(100.dp)
            .shadow(8.dp, RoundedCornerShape(22.dp), ambientColor = ElectricBlue, spotColor = Cyan)
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .background(Brush.verticalGradient(listOf(Color(0xFF12336F), Color(0xFF061638))))
            .border(1.5.dp, Brush.linearGradient(listOf(Cyan, ElectricBlue, Color(0xFF143BFF))), RoundedCornerShape(22.dp))
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
            icon()
            if (accent) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .size(25.dp)
                        .clip(CircleShape)
                        .background(Cyan)
                        .border(1.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, tint = Navy, modifier = Modifier.size(19.dp))
                }
            }
        }
        Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 15.sp)
        Text("›", color = Cyan, fontSize = 36.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun WideActionTile(title: String, icon: @Composable () -> Unit, onClick: () -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(90.dp)
            .shadow(8.dp, RoundedCornerShape(21.dp), ambientColor = ElectricBlue, spotColor = Cyan)
            .clip(RoundedCornerShape(21.dp))
            .clickable(onClick = onClick)
            .background(Brush.verticalGradient(listOf(Color(0xFF12336F), Color(0xFF061638))))
            .border(1.5.dp, Brush.linearGradient(listOf(Cyan, ElectricBlue, Color(0xFF143BFF))), RoundedCornerShape(21.dp))
            .padding(horizontal = 25.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(62.dp), contentAlignment = Alignment.Center) { icon() }
        Box(Modifier.width(1.dp).height(48.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Cyan, Color.Transparent))))
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Text("›", color = Cyan, fontSize = 36.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun SocialMark(platform: String) {
    Box(
        Modifier
            .size(25.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(
                when (platform) {
                    "youtube" -> Brush.linearGradient(
                        listOf(Color(0xFFFF0033), Color(0xFFFF0033))
                    )
                    "instagram" -> Brush.linearGradient(
                        listOf(Color(0xFF833AB4), Color(0xFFE1306C), Color(0xFFFCAF45))
                    )
                    else -> Brush.linearGradient(
                        listOf(Color.Black, Color.Black)
                    )
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize().padding(5.dp)) {
            val white = Color.White
            when (platform) {
                "youtube" -> {
                    val triangle = androidx.compose.ui.graphics.Path().apply {
                        moveTo(size.width * 0.34f, size.height * 0.18f)
                        lineTo(size.width * 0.34f, size.height * 0.82f)
                        lineTo(size.width * 0.82f, size.height * 0.50f)
                        close()
                    }
                    drawPath(triangle, white)
                }
                "instagram" -> {
                    drawRoundRect(
                        color = white,
                        topLeft = androidx.compose.ui.geometry.Offset(size.width * 0.08f, size.height * 0.08f),
                        size = androidx.compose.ui.geometry.Size(size.width * 0.84f, size.height * 0.84f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.width * 0.22f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = size.width * 0.11f)
                    )
                    drawCircle(
                        color = white,
                        radius = size.width * 0.19f,
                        center = androidx.compose.ui.geometry.Offset(size.width * 0.50f, size.height * 0.52f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = size.width * 0.10f)
                    )
                    drawCircle(
                        color = white,
                        radius = size.width * 0.065f,
                        center = androidx.compose.ui.geometry.Offset(size.width * 0.75f, size.height * 0.27f)
                    )
                }
                else -> {
                    val stem = androidx.compose.ui.graphics.Path().apply {
                        moveTo(size.width * 0.58f, size.height * 0.12f)
                        lineTo(size.width * 0.58f, size.height * 0.68f)
                        quadraticTo(size.width * 0.58f, size.height * 0.91f, size.width * 0.34f, size.height * 0.88f)
                    }
                    val cyanStem = androidx.compose.ui.graphics.Path().apply {
                        moveTo(size.width * 0.65f, size.height * 0.10f)
                        lineTo(size.width * 0.65f, size.height * 0.63f)
                    }
                    val redStem = androidx.compose.ui.graphics.Path().apply {
                        moveTo(size.width * 0.51f, size.height * 0.15f)
                        lineTo(size.width * 0.51f, size.height * 0.69f)
                    }
                    drawPath(cyanStem, Color(0xFF25F4EE), style = androidx.compose.ui.graphics.drawscope.Stroke(width = size.width * 0.19f))
                    drawPath(redStem, Color(0xFFFE2C55), style = androidx.compose.ui.graphics.drawscope.Stroke(width = size.width * 0.19f))
                    drawPath(stem, white, style = androidx.compose.ui.graphics.drawscope.Stroke(width = size.width * 0.19f))
                    drawCircle(Color(0xFF25F4EE), size.width * 0.17f, androidx.compose.ui.geometry.Offset(size.width * 0.31f, size.height * 0.79f))
                    drawCircle(white, size.width * 0.13f, androidx.compose.ui.geometry.Offset(size.width * 0.35f, size.height * 0.77f))
                }
            }
        }
    }
}
