package ai.creatoros.smartclip

import android.content.Context
import android.net.Uri
import android.media.MediaExtractor
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaMetadataRetriever
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.common.util.Size
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ExportException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class SmartClipSuggestion(
    val platform: String,
    val title: String,
    val description: String,
    val hashtags: String,
    val startMs: Long,
    val endMs: Long,
    val captions: List<SmartClipCaption> = emptyList()
)

data class SmartClipCaption(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

object VideoAnalysisEngine {
    // Descobre os modelos realmente liberados para esta chave. Prioriza modelos Flash,
    // mas não descarta modelos válidos só porque seus nomes mudaram.
    private fun listGenerativeModels(apiKey: String): List<String> {
        val connection = URL("https://generativelanguage.googleapis.com/v1beta/models").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 20000
            connection.readTimeout = 30000
            connection.setRequestProperty("x-goog-api-key", apiKey)
            val code = connection.responseCode
            val response = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull().orEmpty()
                when (code) {
                    400, 401, 403 -> error("A chave Gemini foi recusada (HTTP $code). Confira a chave e as permissões da API. $detail")
                    else -> error("Não foi possível consultar os modelos Gemini (HTTP $code). $detail")
                }
            }
            val models = JSONObject(response).optJSONArray("models") ?: JSONArray()
            val available = (0 until models.length()).mapNotNull { index ->
                val item = models.optJSONObject(index) ?: return@mapNotNull null
                val methods = item.optJSONArray("supportedGenerationMethods") ?: JSONArray()
                val name = item.optString("name").removePrefix("models/")
                val supportsGenerate = (0 until methods.length()).any { methods.optString(it) == "generateContent" }
                // Gemma e modelos especializados podem aceitar texto, mas não vídeo/imagens.
                // A análise de vídeo usa quadros visuais, portanto exige um modelo Gemini.
                if (!supportsGenerate || !name.startsWith("gemini-", ignoreCase = true)) null
                else name.takeIf { it.isNotBlank() }
            }.toSet()
            return available.sortedWith(
                compareBy<String> { if (it.contains("flash", ignoreCase = true)) 0 else 1 }
                    .thenBy { if (it.contains("lite", ignoreCase = true)) 1 else 0 }
                    .thenByDescending { it }
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun errorDetail(response: String): String =
        runCatching { JSONObject(response).optJSONObject("error")?.optString("message").orEmpty() }
            .getOrDefault("").ifBlank { response.take(500) }

    private fun isUnsupportedVideoModel(detail: String): Boolean {
        val message = detail.lowercase(Locale.ROOT)
        val media = message.contains("video") || message.contains("image") || message.contains("modality")
        val unsupported = message.contains("not support") || message.contains("unsupported") ||
            message.contains("not enabled") || message.contains("doesn't support")
        return media && unsupported
    }

    private fun waitBeforeRetry(attempt: Int) {
        try {
            Thread.sleep(if (attempt == 0) 1000L else 2500L)
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            throw IllegalStateException("A conexão com o Gemini foi interrompida.", interrupted)
        }
    }

    private fun generateWithFallback(
        apiKey: String,
        body: JSONObject,
        models: List<String>,
        onModel: ((String) -> Unit)? = null
    ): Pair<String, String> {
        require(models.isNotEmpty()) {
            "A API não retornou nenhum modelo Gemini com suporte a generateContent para esta chave. Confira o acesso à API."
        }
        var lastCode = 0
        var lastResponse = ""
        for (model in models) {
            onModel?.invoke(model)
            for (attempt in 0..2) {
                val connection = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .openConnection() as HttpURLConnection
                try {
                    connection.requestMethod = "POST"
                    connection.doOutput = true
                    connection.connectTimeout = 30000
                    connection.readTimeout = 180000
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    connection.setRequestProperty("Accept", "application/json")
                    connection.setRequestProperty("x-goog-api-key", apiKey)
                    connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    lastCode = connection.responseCode
                    lastResponse = (if (lastCode in 200..299) connection.inputStream else connection.errorStream)
                        ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                } catch (network: java.io.IOException) {
                    if (attempt < 2) {
                        waitBeforeRetry(attempt)
                        continue
                    }
                    throw IllegalStateException(
                        "Falha de rede ao conectar ao Gemini. Verifique a internet e tente novamente. ${network.message.orEmpty()}",
                        network
                    )
                } finally {
                    connection.disconnect()
                }

                if (lastCode in 200..299) return model to lastResponse
                val detail = errorDetail(lastResponse)
                if (lastCode == 400) {
                    if (isUnsupportedVideoModel(detail)) break
                    error("O Google recusou os dados enviados (HTTP 400). Confira o vídeo e tente novamente. $detail")
                }
                if (lastCode == 401 || lastCode == 403) {
                    error("A chave Gemini foi recusada ou não tem permissão (HTTP $lastCode). Confira a chave e o acesso à API. $detail")
                }
                if (lastCode == 429) {
                    error("O Gemini atingiu o limite de uso (HTTP 429). Aguarde a renovação da cota antes de tentar novamente. $detail")
                }
                if (lastCode == 404) break
                if (lastCode == 408 || lastCode == 425 || lastCode == 500 ||
                    lastCode == 502 || lastCode == 503 || lastCode == 504
                ) {
                    if (attempt < 2) {
                        waitBeforeRetry(attempt)
                        continue
                    }
                    error("O Gemini está temporariamente indisponível (HTTP $lastCode). Tente novamente mais tarde. $detail")
                }
                error("Erro na comunicação com o Gemini (HTTP $lastCode). $detail")
            }
        }
        error("Nenhum dos modelos disponíveis conseguiu analisar este vídeo. Verifique a compatibilidade do modelo e tente novamente. HTTP $lastCode. ${errorDetail(lastResponse)}")
    }

    fun testConnection(apiKey: String): String {
        require(apiKey.isNotBlank()) { "Digite a chave da API Gemini." }
        val models = listGenerativeModels(apiKey)
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Responda apenas: OK")))))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 8))
        val (model, _) = generateWithFallback(apiKey, body, models)
        return "Conexão Gemini válida! A chave foi aceita e o modelo $model respondeu ao teste de texto. O envio de vídeo será validado durante uma análise."
    }

    fun analyze(context: Context, videoUri: Uri, apiKey: String, requestedCount: Int, requestedDurationSeconds: Int, onStatus: (String) -> Unit): List<SmartClipSuggestion> {
        require(apiKey.isNotBlank()) { "Adicione sua chave Gemini em Configurações > Adicionar API." }

        // Valida o acesso aos modelos antes de copiar/enviar um vídeo grande.
        // Erros de chave, permissão ou disponibilidade não desperdiçam tempo no upload.
        onStatus("Verificando disponibilidade do Gemini...")
        val availableModels = listGenerativeModels(apiKey)

        onStatus("Preparando vídeo...")
        val input = copyUriToCache(context, videoUri)
        var uploadedFileName: String? = null
        try {
            onStatus("Enviando vídeo ao Gemini...")
            val mimeType = context.contentResolver.getType(videoUri) ?: "video/mp4"
            var file = uploadVideo(input, apiKey, mimeType)
            uploadedFileName = file.optString("name").takeIf { it.isNotBlank() }
            require(uploadedFileName != null) { "O Gemini não retornou o identificador do vídeo enviado." }
            val processingStartedAt = System.nanoTime()
            var pollCount = 0
            while (file.optString("state") != "ACTIVE") {
                val state = file.optString("state").uppercase(Locale.ROOT)
                if (state == "FAILED") error("O Gemini não conseguiu processar o vídeo. Tente outro formato.")
                require(state == "PROCESSING" || state.isBlank()) {
                    "O Gemini retornou um estado inesperado para o vídeo: $state."
                }
                val elapsedSeconds = (System.nanoTime() - processingStartedAt) / 1_000_000_000L
                if (elapsedSeconds >= 600L) {
                    error("O processamento do vídeo ultrapassou 10 minutos. Tente novamente com um vídeo menor.")
                }
                pollCount++
                try {
                    Thread.sleep(if (pollCount <= 5) 2000L else 5000L)
                } catch (interrupted: InterruptedException) {
                    Thread.currentThread().interrupt()
                    error("O processamento do vídeo foi interrompido.")
                }
                file = getFile(file.getString("name"), apiKey)
                onStatus("Gemini processando vídeo... (${elapsedSeconds}s)")
            }
            onStatus("Identificando os melhores momentos...")
            return requestSuggestions(file.getString("uri"), file.optString("mimeType", mimeType), apiKey, requestedCount, requestedDurationSeconds, availableModels, onStatus)
        } finally {
            // Remove a cópia remota após a análise, inclusive quando ocorre erro.
            // A limpeza é best-effort e não altera o resultado principal.
            uploadedFileName?.let { name -> runCatching { deleteUploadedFile(name, apiKey) } }
            input.delete()
        }
    }

    private fun deleteUploadedFile(name: String, apiKey: String) {
        val encodedName = name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8") }
        val connection = URL("https://generativelanguage.googleapis.com/v1beta/$encodedName")
            .openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "DELETE"
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.setRequestProperty("x-goog-api-key", apiKey)
            connection.responseCode
        } finally {
            connection.disconnect()
        }
    }

    private fun copyUriToCache(context: Context, uri: Uri): File {
        val file = File.createTempFile("smartclip_input_", ".mp4", context.cacheDir)
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: error("Não foi possível abrir o vídeo selecionado.")
            inputStream.use { input ->
                file.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
            }
            require(file.length() > 0L) { "O vídeo selecionado está vazio." }
            return file
        } catch (error: Exception) {
            // Não deixa arquivos temporários órfãos se a leitura/cópia falhar.
            file.delete()
            throw error
        }
    }

    private fun uploadVideo(file: File, apiKey: String, mimeType: String): JSONObject {
        val start = URL("https://generativelanguage.googleapis.com/upload/v1beta/files").openConnection() as HttpURLConnection
        val uploadUrl: String
        val startCode: Int
        try {
            start.requestMethod = "POST"
            start.doOutput = true
            start.connectTimeout = 30000
            start.readTimeout = 30000
            start.setRequestProperty("X-Goog-Upload-Protocol", "resumable")
            start.setRequestProperty("X-Goog-Upload-Command", "start")
            start.setRequestProperty("X-Goog-Upload-Header-Content-Length", file.length().toString())
            start.setRequestProperty("X-Goog-Upload-Header-Content-Type", mimeType)
            start.setRequestProperty("Content-Type", "application/json")
            start.setRequestProperty("x-goog-api-key", apiKey)
            start.outputStream.use {
                it.write(JSONObject().put("file", JSONObject().put("display_name", file.name)).toString().toByteArray(Charsets.UTF_8))
            }
            uploadUrl = start.getHeaderField("X-Goog-Upload-URL") ?: start.getHeaderField("Location").orEmpty()
            startCode = start.responseCode
            if (startCode !in 200..299 || uploadUrl.isBlank()) {
                val detail = start.errorStream
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                error("Falha ao iniciar envio ao Gemini ($startCode): $detail")
            }
        } finally {
            start.disconnect()
        }

        val upload = URL(uploadUrl).openConnection() as HttpURLConnection
        try {
            upload.requestMethod = "POST"
            upload.doOutput = true
            upload.connectTimeout = 60000
            upload.readTimeout = 120000
            upload.setFixedLengthStreamingMode(file.length())
            upload.setRequestProperty("X-Goog-Upload-Offset", "0")
            upload.setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
            upload.setRequestProperty("Content-Type", mimeType)
            file.inputStream().use { input ->
                upload.outputStream.use { output -> input.copyTo(output, 64 * 1024) }
            }
            val code = upload.responseCode
            val body = (if (code in 200..299) upload.inputStream else upload.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("Falha ao enviar vídeo ao Gemini ($code): $body")
            val root = JSONObject(body)
            return root.optJSONObject("file") ?: root
        } finally {
            upload.disconnect()
        }
    }

    private fun getFile(name: String, apiKey: String): JSONObject {
        val encodedName = name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8") }
        val connection = URL("https://generativelanguage.googleapis.com/v1beta/$encodedName").openConnection() as HttpURLConnection
        connection.connectTimeout = 20000
        connection.readTimeout = 20000
        connection.setRequestProperty("x-goog-api-key", apiKey)
        val code: Int
        val body: String
        try {
            code = connection.responseCode
            body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
        } finally {
            connection.disconnect()
        }
        if (code !in 200..299) error("Erro ao consultar processamento ($code): $body")
        val root = JSONObject(body)
        return root.optJSONObject("file") ?: root
    }

    private fun requestSuggestions(fileUri: String, mimeType: String, apiKey: String, requestedCount: Int, requestedDurationSeconds: Int, models: List<String>, onStatus: (String) -> Unit): List<SmartClipSuggestion> {
        val count = requestedCount.coerceIn(1, 30)
        val durationRule = if (requestedDurationSeconds > 0) "Cada corte deve ter aproximadamente $requestedDurationSeconds segundos (pode variar para preservar o contexto)." else "Escolha a duração ideal de cada corte, priorizando momentos completos e envolventes."
        val prompt = """
            Analise o vídeo inteiro e encontre os melhores momentos independentes para criar vídeos curtos.
            Gere exatamente $count cortes para CADA plataforma: YouTube, Instagram e TikTok.
            $durationRule
            Os tempos start_seconds e end_seconds devem ser precisos, em segundos decimais, dentro da duração real do vídeo.
            Cada corte deve começar antes do momento importante e terminar depois dele, sem cortar palavras ou ações no meio.
            Priorize momentos com gancho inicial, clareza, valor e potencial de retenção. Evite cortes repetidos.
            Crie título, descrição e hashtags específicos para a plataforma e em português brasileiro.
            Para cada corte, gere também "caption_segments": frases curtas transcritas EXATAMENTE do áudio em português, com start_seconds e end_seconds absolutos em relação ao vídeo original. Cada frase deve aparecer sincronizada com a fala, sem inventar palavras. Se não houver fala audível, use uma lista vazia.
            Retorne SOMENTE JSON válido neste formato:
            {"clips":[{"platform":"YouTube","title":"...","description":"...","hashtags":"#... #...","start_seconds":1.2,"end_seconds":25.0,"caption_segments":[{"start_seconds":2.0,"end_seconds":3.8,"text":"Frase falada aqui"}]}]}
            Use platform exatamente como YouTube, Instagram ou TikTok. Não inclua markdown nem texto fora do JSON.
        """.trimIndent()
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("file_data", JSONObject().put("mime_type", mimeType).put("file_uri", fileUri)))
        val content = JSONObject().put("parts", parts)
        val body = JSONObject()
            .put("contents", JSONArray().put(content))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val (_, responseText) = generateWithFallback(apiKey, body, models) { model ->
            onStatus("Tentando análise com $model...")
        }
        val response = JSONObject(responseText)
        val candidates = response.optJSONArray("candidates") ?: JSONArray()
        val candidate = candidates.optJSONObject(0)
        val generated = candidate?.optJSONObject("content")?.optJSONArray("parts")
            ?.let { parts ->
                (0 until parts.length()).mapNotNull { index ->
                    parts.optJSONObject(index)?.optString("text")?.takeIf { it.isNotBlank() }
                }.joinToString("\\n")
            }.orEmpty()
        if (generated.isBlank()) {
            val blockReason = response.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            val finishReason = candidate?.optString("finishReason").orEmpty()
            error("O Gemini não retornou uma análise utilizável. ${blockReason.ifBlank { finishReason }.ifBlank { "Resposta vazia" }}")
        }
        var jsonText = generated.trim().removePrefix("```json").removePrefix("```")
            .removeSuffix("```").trim()
        val jsonStart = jsonText.indexOf('{')
        val jsonEnd = jsonText.lastIndexOf('}')
        if (jsonStart >= 0 && jsonEnd > jsonStart) jsonText = jsonText.substring(jsonStart, jsonEnd + 1)
        val clips = runCatching { JSONObject(jsonText).getJSONArray("clips") }
            .getOrElse { error("O Gemini respondeu, mas o formato dos cortes veio inválido. Tente novamente.") }
        val result = mutableListOf<SmartClipSuggestion>()
        val allowedPlatforms = setOf("youtube", "instagram", "tiktok")
        val seen = mutableSetOf<String>()
        for (index in 0 until clips.length()) {
            val item = clips.optJSONObject(index) ?: continue
            val platformRaw = item.optString("platform").trim()
            val platform = when (platformRaw.lowercase(Locale.ROOT)) {
                "youtube" -> "YouTube"
                "instagram" -> "Instagram"
                "tiktok", "tik tok" -> "TikTok"
                else -> continue
            }
            if (platformRaw.lowercase(Locale.ROOT) !in allowedPlatforms && platformRaw.lowercase(Locale.ROOT) != "tik tok") continue
            val startSeconds = item.optDouble("start_seconds", Double.NaN)
            val endSeconds = item.optDouble("end_seconds", Double.NaN)
            if (!startSeconds.isFinite() || !endSeconds.isFinite() || startSeconds < 0.0 || endSeconds <= startSeconds) continue
            if (endSeconds - startSeconds < 1.0 || endSeconds > 24.0 * 60.0 * 60.0) continue
            val start = (startSeconds * 1000.0).toLong()
            val end = (endSeconds * 1000.0).toLong()
            val title = item.optString("title").trim().ifBlank { "Corte ${index + 1}" }
            val captionArray = item.optJSONArray("caption_segments") ?: JSONArray()
            val captions = (0 until captionArray.length()).mapNotNull { captionIndex ->
                val caption = captionArray.optJSONObject(captionIndex) ?: return@mapNotNull null
                val captionStart = caption.optDouble("start_seconds", Double.NaN)
                val captionEnd = caption.optDouble("end_seconds", Double.NaN)
                val captionText = caption.optString("text").trim()
                if (!captionStart.isFinite() || !captionEnd.isFinite() || captionEnd <= captionStart ||
                    captionText.isBlank() || captionStart < startSeconds - 0.5 || captionEnd > endSeconds + 0.5
                ) return@mapNotNull null
                SmartClipCaption(
                    startMs = ((captionStart - startSeconds).coerceAtLeast(0.0) * 1000.0).toLong(),
                    endMs = ((captionEnd - startSeconds).coerceAtLeast(0.0) * 1000.0).toLong(),
                    text = captionText.take(180)
                )
            }.filter { it.endMs > it.startMs }.sortedBy { it.startMs }
            val signature = "${platform.lowercase(Locale.ROOT)}:$start:$end"
            if (!seen.add(signature)) continue
            result += SmartClipSuggestion(
                platform = platform,
                title = title.take(180),
                description = item.optString("description").take(2200),
                hashtags = item.optString("hashtags").take(1000),
                startMs = start,
                endMs = end,
                captions = captions
            )
        }
        require(result.isNotEmpty()) { "O Gemini não retornou cortes válidos. Confira se o vídeo possui conteúdo e tente novamente." }
        return result
    }
}

object VideoCutEngine {
    fun cut(context: Context, sourceUri: Uri, suggestion: SmartClipSuggestion, index: Int): File {
        val extractor = MediaExtractor()
        val output = File(context.cacheDir, "smartclip_${suggestion.platform.lowercase(Locale.ROOT)}_${index + 1}_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(8)}.mp4")
        if (output.exists()) output.delete()

        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var retriever: MediaMetadataRetriever? = null

        try {
            extractor.setDataSource(context, sourceUri, null)
            retriever = MediaMetadataRetriever()
            val durationMs = runCatching {
                retriever.setDataSource(context, sourceUri)
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            }.getOrNull()

            val startUs = suggestion.startMs.coerceAtLeast(0L) * 1000L
            val requestedEndMs = suggestion.endMs
            val safeEndMs = if (durationMs != null && durationMs > 0L) {
                requestedEndMs.coerceAtMost(durationMs)
            } else requestedEndMs
            val endUs = safeEndMs * 1000L
            require(endUs > startUs) { "O tempo final do corte é anterior ao início ou está fora da duração do vídeo." }
            if (durationMs != null && durationMs > 0L) {
                require(startUs < durationMs * 1000L) { "O início do corte está fora da duração do vídeo." }
            }

            val trackMap = mutableMapOf<Int, Int>()
            var maxInputSize = 8 * 1024 * 1024
            for (track in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(track)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        maxInputSize = maxOf(maxInputSize, runCatching {
                            format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                        }.getOrDefault(0))
                    }
                    trackMap[track] = trackMap.size
                    extractor.selectTrack(track)
                }
            }
            require(trackMap.isNotEmpty()) { "Não foi encontrada faixa de áudio ou vídeo." }

            // Usa o tamanho máximo informado pelos próprios codecs, evitando estouro
            // do buffer em quadros de alta resolução/alto bitrate.
            require(maxInputSize <= 32 * 1024 * 1024) {
                "Este vídeo possui quadros grandes demais para o cortador processar com segurança."
            }
            val buffer = java.nio.ByteBuffer.allocate(maxInputSize)

            runCatching {
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                    ?.toIntOrNull()?.let { rotation ->
                        // A orientação precisa ser definida antes de iniciar o muxer.
                        muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                        muxer.setOrientationHint(rotation)
                    }
            }
            if (muxer == null) {
                muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            }

            val targetMuxer = muxer!!
            for (track in 0 until extractor.trackCount) {
                val destinationTrack = trackMap[track] ?: continue
                // Reobtém o formato original para manter codec, perfil e parâmetros.
                targetMuxer.addTrack(extractor.getTrackFormat(track))
            }

            // O seek é feito antes de iniciar a escrita. Em cópia direta, o início
            // fica alinhado ao quadro-chave anterior para manter o vídeo decodificável.
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val firstSampleTimeUs = extractor.sampleTime
            require(firstSampleTimeUs >= 0L) { "Não foi encontrado um quadro válido próximo ao início solicitado." }

            targetMuxer.start()
            muxerStarted = true

            val info = MediaCodec.BufferInfo()
            var writtenSamples = 0
            val lastWrittenTimeByTrack = mutableMapOf<Int, Long>()

            while (true) {
                val sourceTrack = extractor.sampleTrackIndex
                if (sourceTrack < 0) break
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs < 0L || sampleTimeUs > endUs) break

                val destinationTrack = trackMap[sourceTrack]
                if (destinationTrack != null) {
                    buffer.clear()
                    val size = extractor.readSampleData(buffer, 0)
                    if (size > 0) {
                        val presentationTimeUs = (sampleTimeUs - firstSampleTimeUs).coerceAtLeast(0L)
                        val previousTime = lastWrittenTimeByTrack[destinationTrack]
                        // MediaMuxer exige timestamps não decrescentes dentro de cada faixa.
                        if (previousTime == null || presentationTimeUs >= previousTime) {
                            // MediaExtractor e MediaCodec usam conjuntos de flags diferentes.
                            // Convertemos apenas os sinalizadores compatíveis com MediaMuxer.
                            val sourceFlags = extractor.sampleFlags
                            require(sourceFlags and MediaExtractor.SAMPLE_FLAG_ENCRYPTED == 0) {
                                "Não é possível copiar diretamente amostras de vídeo criptografadas."
                            }
                            var muxerFlags = 0
                            if (sourceFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
                                muxerFlags = muxerFlags or MediaCodec.BUFFER_FLAG_KEY_FRAME
                            }
                            // Esses sinalizadores só existem a partir do Android 8.0 (API 26).
                            // O app aceita Android 6.0 (API 23), então evita acessar os campos
                            // em versões antigas para não provocar NoSuchFieldError.
                            if (android.os.Build.VERSION.SDK_INT >= 26 &&
                                sourceFlags and MediaExtractor.SAMPLE_FLAG_PARTIAL_FRAME != 0
                            ) {
                                muxerFlags = muxerFlags or MediaCodec.BUFFER_FLAG_PARTIAL_FRAME
                            }
                            info.set(0, size, presentationTimeUs, muxerFlags)
                            targetMuxer.writeSampleData(destinationTrack, buffer, info)
                            lastWrittenTimeByTrack[destinationTrack] = presentationTimeUs
                            writtenSamples++
                        }
                    }
                }
                if (!extractor.advance()) break
            }

            require(writtenSamples > 0) {
                "O corte ${index + 1} ficou vazio. Tente novamente ou escolha outro vídeo."
            }
            // Finaliza o contêiner MP4 antes de devolver o arquivo; o stop grava
            // índices e metadados necessários para players reconhecerem o vídeo.
            targetMuxer.stop()
            muxerStarted = false
            require(output.exists() && output.length() > 0L) {
                "Não foi possível finalizar o arquivo do corte ${index + 1}."
            }
            return output
        } catch (error: Exception) {
            output.delete()
            throw error
        } finally {
            if (muxerStarted) runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { retriever?.release() }
            runCatching { extractor.release() }
        }
    }
}


@UnstableApi
object VideoCaptionBurner {
    suspend fun burn(context: Context, input: File, captions: List<SmartClipCaption>, index: Int): File =
        suspendCancellableCoroutine { continuation ->
            val output = File(context.cacheDir, "smartclip_captioned_\${index + 1}_\${System.currentTimeMillis()}.mp4")
            runCatching {
                val overlay = object : BitmapOverlay() {
                    private var videoWidth = 1080
                    private var videoHeight = 1920
                    private var cachedCaption: SmartClipCaption? = null
                    private var cachedBitmap: Bitmap? = null

                    override fun configure(videoSize: Size) {
                        videoWidth = videoSize.width.coerceAtLeast(1)
                        videoHeight = videoSize.height.coerceAtLeast(1)
                        cachedBitmap?.recycle()
                        cachedBitmap = null
                        cachedCaption = null
                    }

                    override fun getBitmap(presentationTimeUs: Long): Bitmap {
                        val caption = captions.firstOrNull {
                            presentationTimeUs >= it.startMs * 1000L && presentationTimeUs <= it.endMs * 1000L
                        }
                        if (caption == cachedCaption && cachedBitmap != null) return cachedBitmap!!
                        cachedBitmap?.recycle()
                        val bitmap = Bitmap.createBitmap(videoWidth, videoHeight, Bitmap.Config.ARGB_8888)
                        cachedBitmap = bitmap
                        cachedCaption = caption
                        if (caption == null) return bitmap

                        val canvas = Canvas(bitmap)
                        val fillPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.rgb(255, 213, 79)
                            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                        }
                        val strokePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.rgb(20, 17, 10)
                            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                            style = Paint.Style.STROKE
                            strokeJoin = Paint.Join.ROUND
                        }
                        val width = (videoWidth * 0.88f).toInt().coerceAtLeast(1)
                        val size = videoWidth * 0.052f
                        fillPaint.textSize = size
                        strokePaint.textSize = size
                        strokePaint.strokeWidth = size * 0.12f
                        val text = caption.text
                        val fillLayout = StaticLayout.Builder.obtain(text, 0, text.length, fillPaint, width)
                            .setAlignment(Layout.Alignment.ALIGN_CENTER)
                            .setIncludePad(false)
                            .setMaxLines(2)
                            .setEllipsize(TextUtils.TruncateAt.END)
                            .build()
                        val strokeLayout = StaticLayout.Builder.obtain(text, 0, text.length, strokePaint, width)
                            .setAlignment(Layout.Alignment.ALIGN_CENTER)
                            .setIncludePad(false)
                            .setMaxLines(2)
                            .setEllipsize(TextUtils.TruncateAt.END)
                            .build()
                        val x = (videoWidth - width) / 2f
                        val y = videoHeight - fillLayout.height - videoHeight * 0.075f
                        canvas.save()
                        canvas.translate(x, y)
                        strokeLayout.draw(canvas)
                        fillLayout.draw(canvas)
                        canvas.restore()
                        return bitmap
                    }

                    override fun release() {
                        cachedBitmap?.recycle()
                        cachedBitmap = null
                        cachedCaption = null
                        super.release()
                    }
                }
                val effects = Effects(emptyList(), listOf(OverlayEffect(listOf(overlay))))
                val edited = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input)))
                    .setEffects(effects)
                    .build()
                val transformer = Transformer.Builder(context)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (continuation.isActive) {
                                if (output.exists() && output.length() > 0L) continuation.resume(output)
                                else continuation.resumeWithException(IllegalStateException("O vídeo com legendas não foi finalizado."))
                            }
                        }

                        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                            output.delete()
                            if (continuation.isActive) continuation.resumeWithException(
                                IllegalStateException("Não foi possível inserir as legendas no vídeo: \${exportException.message}", exportException)
                            )
                        }
                    })
                    .build()
                continuation.invokeOnCancellation { runCatching { transformer.cancel() }; output.delete() }
                transformer.start(edited, output.absolutePath)
            }.onFailure { error ->
                output.delete()
                if (continuation.isActive) continuation.resumeWithException(error)
            }
        }
}
